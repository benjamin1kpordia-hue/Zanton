# Enviar vídeos para o YouTube

## 1. Credenciais do Google (uma vez só)
1. Abra https://console.cloud.google.com e crie um projeto.
2. Em "APIs e serviços" > "Biblioteca", ative a **YouTube Data API v3**.
3. Em "Tela de consentimento OAuth", configure o app e adicione seu e-mail como **usuário de teste**.
4. Em "Credenciais" > "Criar credenciais" > "ID do cliente OAuth" (tipo **Aplicativo da Web**).
   Em "URIs de redirecionamento autorizados", coloque: `http://localhost:3000/auth/callback`
5. Copie o ID e o segredo do cliente.

## 2. Rodar
```
cp .env.example .env     # preencha com o ID e o segredo
npm install
npm start
```
Abra http://localhost:3000, clique em **Conectar conta do Google**, escolha o vídeo e clique em **Upload**.

## Avisos
- Apps novos e não verificados pelo Google têm os vídeos travados como **privados** até passarem pela auditoria da API do YouTube. Para uso pessoal, isso costuma bastar.
- A cota padrão (10.000 unidades/dia) permite cerca de 6 uploads por dia.
- Ao publicar o site em um domínio, troque `REDIRECT_URI` (no `.env` e no Google Cloud) pela URL real com HTTPS.
- Os tokens ficam na sessão em memória. Para produção, use um armazenamento persistente (Redis, banco de dados).
