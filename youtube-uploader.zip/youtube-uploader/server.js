require('dotenv').config();
const express = require('express');
const session = require('express-session');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { google } = require('googleapis');

const {
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  REDIRECT_URI = 'http://localhost:3000/auth/callback',
  SESSION_SECRET = 'troque-esta-chave',
  PORT = 3000,
} = process.env;

const SCOPES = [
  'https://www.googleapis.com/auth/youtube.upload',
  'https://www.googleapis.com/auth/userinfo.profile',
];

const app = express();
app.use(express.json());
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 },
  })
);
app.use(express.static(path.join(__dirname, 'public')));

const upload = multer({
  dest: path.join(os.tmpdir(), 'yt-uploads'),
  limits: { fileSize: 4 * 1024 ** 3 }, // 4 GB
  fileFilter: (req, file, cb) => cb(null, file.mimetype.startsWith('video/')),
});

const newClient = () =>
  new google.auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, REDIRECT_URI);

// 1) Redireciona para a tela de consentimento do Google
app.get('/auth/google', (req, res) => {
  const state = crypto.randomBytes(16).toString('hex');
  req.session.oauthState = state;
  const url = newClient().generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: SCOPES,
    state,
  });
  res.redirect(url);
});

// 2) Google devolve o usuário aqui com um código
app.get('/auth/callback', async (req, res) => {
  try {
    if (!req.query.code || req.query.state !== req.session.oauthState) {
      return res.status(400).send('Falha na autenticação. Tente conectar novamente.');
    }
    const client = newClient();
    const { tokens } = await client.getToken(req.query.code);
    client.setCredentials(tokens);

    const { data } = await google.oauth2({ version: 'v2', auth: client }).userinfo.get();
    req.session.tokens = tokens;
    req.session.user = { name: data.name, picture: data.picture };
    res.redirect('/');
  } catch (err) {
    console.error(err);
    res.status(500).send('Não foi possível conectar à conta do Google.');
  }
});

app.get('/api/me', (req, res) => {
  const user = req.session.user;
  res.json(user && req.session.tokens ? { connected: true, ...user } : { connected: false });
});

app.post('/auth/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// 3) Recebe o vídeo e publica no YouTube com a conta conectada
app.post('/api/upload', upload.single('video'), async (req, res) => {
  const file = req.file;
  try {
    if (!req.session.tokens) return res.status(401).json({ error: 'Conecte sua conta do Google primeiro.' });
    if (!file) return res.status(400).json({ error: 'Envie um arquivo de vídeo.' });

    const title = (req.body.title || '').trim().slice(0, 100);
    if (!title) return res.status(400).json({ error: 'Informe um título.' });

    const privacy = ['private', 'unlisted', 'public'].includes(req.body.privacy)
      ? req.body.privacy
      : 'private';

    const client = newClient();
    client.setCredentials(req.session.tokens);
    client.on('tokens', (t) => {
      req.session.tokens = { ...req.session.tokens, ...t };
    });

    const youtube = google.youtube({ version: 'v3', auth: client });
    const { data } = await youtube.videos.insert({
      part: ['snippet', 'status'],
      requestBody: {
        snippet: { title, description: (req.body.description || '').slice(0, 5000) },
        status: { privacyStatus: privacy, selfDeclaredMadeForKids: false },
      },
      media: { body: fs.createReadStream(file.path) },
    });

    res.json({ id: data.id, url: `https://www.youtube.com/watch?v=${data.id}` });
  } catch (err) {
    console.error(err?.response?.data || err);
    const reason = err?.errors?.[0]?.reason;
    const msg =
      reason === 'quotaExceeded'
        ? 'A cota diária da API do YouTube acabou. Tente amanhã.'
        : err?.response?.status === 401
        ? 'Sua conexão expirou. Conecte a conta novamente.'
        : 'O YouTube recusou o envio. Veja o log do servidor para detalhes.';
    res.status(500).json({ error: msg });
  } finally {
    if (file) fs.unlink(file.path, () => {});
  }
});

app.listen(PORT, () => console.log(`Rodando em http://localhost:${PORT}`));
